# Document Photo Studio

A static HTML/CSS/JavaScript photo preparation tool for GitHub Pages or Vercel. No build step or paid API is required.

## Files
- `index.html` — photo editor, size presets, solid background, exports and print sheets
- `about.html` — About page
- `contact.html` — Contact page (replace example email)
- `privacy.html` — privacy policy template
- `terms.html` — terms template
- `page.css` — shared styling for informational pages

## Important limitations
- Presets are common/generic working dimensions; verify the current authority or application requirements before submitting.
- Background colours fill the canvas. They do not remove the source background from a person. AI background removal is not included.
- File-size target is best-effort.
- The canonical URL in `index.html` is a placeholder. Replace it with your real deployed URL after publishing.
- Replace `YOUR-CONTACT-EMAIL@example.com` in `contact.html` before publishing.
- Privacy/terms pages are starter templates, not legal advice. Keep them accurate to any analytics, ads or other services you add later.

## Deploy from a phone
1. Open your GitHub repository in Safari and choose **Add file → Create new file**.
2. Create each file using the exact filename above, paste its complete contents, then commit the file.
3. In Vercel, import the GitHub repository or open the existing project and ensure the root directory is `./`. No build command is needed for a static HTML site.
4. For GitHub Pages, open repository **Settings → Pages**, select deployment from the main branch and root folder, then save.
5. Open the deployed URL and test upload, preset selection, background, downloads and print sheet on your phone.
